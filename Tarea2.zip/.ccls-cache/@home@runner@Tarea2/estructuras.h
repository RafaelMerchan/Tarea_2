#define MAXN 15213
/*
#ifdef MATERIA_H
struct materia{
  char nombre[50];
  char paralelo[50];
  int creditos;
};
void printMateria(struct materia materias[], int num);  
#endif

#ifdef ESTUDIANTE_H
struct estudiante{
  char nombre[50];
  char nivel[50];
  char carrera[50];
  int numMaterias;
  struct materia materias[MAXN];
};
struct estudiante crearEstudiante();
void agregarMateriaEstudiante(struct estudiante e);
void printEstudiante(struct estudiante e);
#endif

#ifdef PROFESOR_H
struct profesor{
  char nombre[50];
  char carrera[50];
  int numMaterias;
  struct materia materias[MAXN];
};
struct profesor crearProfesor();
void agregarMateriaProfesor(struct profesor p);  
void printProfesor(struct profesor p);
#endif*/