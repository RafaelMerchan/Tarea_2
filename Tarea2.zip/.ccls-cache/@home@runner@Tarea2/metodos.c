#include <stdio.h>
#include "estructuras.h"


//ESTUDIANTE
struct estudiante crearEstudiante(){
  struct estudiante e;
  int materias;
  char nombre;
  printf("Nombre del estudiante\n");
  scanf("%s", e.nombre);
  //strcpy(e.nombre, nombre);
  printf("Nivel del estudiante\n");
  scanf("%50s", e.nivel);
  printf("Carrera del estudiante\n");
  scanf("%50s", e.carrera);
  printf("Número de materias\n");
  scanf("%d", &e.numMaterias);
  agregarMateriaEstudiante(e);
  return e;
}

void agregarMateriaEstudiante(struct estudiante e){
  for (int i = 0; i < e.numMaterias; i++ ){
    struct materia m;
    printf("Nombre de la materia\n");
    scanf("%s", &m.nombre);
    printf("Créditos de la materia\n");
    scanf("%d", &m.creditos);
    e.materias[i] = m;  
  }
  
}
void printEstudiante(struct estudiante e){
    printf("Estudiante\n");
    printf("Nombre: %s\n", *e.nombre);
    printf("Nivel: %s\n", *e.nivel);
    printf("Carrera: %s\n", *e.carrera);
    printf("Número: %d\n", e.numMaterias);
    printMateria(e.materias, e.numMaterias);
  }
}

// MATERIA
void printMateria(struct materia materias[], int num){
  for (int i = 0; i < num; i++){
    struct materia m = materias[i];
    printf("Materia: %50c \n", m.nombre);
    if (m.paralelo != NULL){
      printf("Paralelo: %50c \n", m.paralelo);
    }
    if (m.creditos != NULL){
      printf("Creditos: %d \n", m.creditos);
    }  
  }
  
}  

// PROFESOR
struct profesor crearProfesor(){
  struct profesor p;
  int materias;
  printf("Nombre del profesor\n");
  scanf("%50c", p.nombre);
  printf("Nombre de la carrera\n");
  scanf("%50c", p.carrera);
  printf("Número de materias\n");
  scanf("%d", &p.numMaterias);
  agregarMateriaProfesor(p);
  return p;
}

void agregarMateriaProfesor(struct profesor p){
  for (int i = 0; i < p.numMaterias; i++ ){
    struct materia m;
    printf("Nombre de la materia\n");
    scanf("%50c", &m.nombre);
    printf("Paralelo de la materia\n");
    scanf("%50c", &m.paralelo);
    p.materias[i] = m;  
  }
}
void printProfesor(struct profesor p){
    printf("Profesor\n");
    printf("Nombre del profesor: %c\n", *p.nombre);
    printf("Carrera del profesor: %c\n", *p.carrera);
    printf("Número de materias: %d\n", p.numMaterias);
    printMateria(p.materias, p.numMaterias);
  }
} 